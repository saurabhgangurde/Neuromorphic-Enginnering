Name: Saurabh Gangurde(14D070009)
	  Ashwin Lele(14D070013)

HW1

please find questionwise pdf report in reports folder and corresponding codes in codes folder.
main codesa are in q1.m,q2.m,q3.m and q4.m files otheer files contains user defined function needed in solving HW.
