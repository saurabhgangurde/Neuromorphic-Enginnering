function [C,ENa,EK,EL,gNa,gK,gL]=neuron_data_q4()

    C = 1;
    ENa = 50;
    EK = - 77;
    EL = - 55;
    gNa = 120;
    gK = 36 ;
    gL = 0.3;
end
